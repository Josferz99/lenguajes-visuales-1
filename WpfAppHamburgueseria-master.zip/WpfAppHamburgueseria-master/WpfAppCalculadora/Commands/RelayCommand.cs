﻿using System;
using System.Windows.Input;

namespace WpfAppHamburgueseria.Commands
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object> ejecutar;
        private readonly Predicate<object> puedeEjecutar;

        public RelayCommand(Action<object> ejecutar, Predicate<object> puedeEjecutar = null)
        {
            this.ejecutar = ejecutar ?? throw new ArgumentNullException(nameof(ejecutar));
            this.puedeEjecutar = puedeEjecutar;
        }

        public bool CanExecute(object parameter) => puedeEjecutar == null || puedeEjecutar(parameter);

        public void Execute(object parameter) => ejecutar(parameter);

        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}
