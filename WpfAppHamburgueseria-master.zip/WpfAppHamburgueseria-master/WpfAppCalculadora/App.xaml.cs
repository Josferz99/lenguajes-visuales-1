﻿using System.Windows;
using WpfAppHamburgueseria.Views;

namespace WpfAppHamburgueseria
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            var login = new LoginView();
            login.InitializeComponent(); // Ensure the component is initialized to avoid ambiguity  
            login.Show();
        }
    }
}
