using System;
using System.Collections.Generic;

namespace WpfAppHamburgueseria.Models
{
    public class Pedido
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public DateTime Fecha { get; set; }
        public decimal Total { get; set; }

        public List<DetallePedido> Detalles { get; set; }
    }
}
