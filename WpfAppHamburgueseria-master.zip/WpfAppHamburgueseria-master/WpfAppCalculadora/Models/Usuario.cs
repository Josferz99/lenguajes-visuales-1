﻿namespace WpfAppHamburgueseria.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public required string Usuarios { get; set; }
        public required string Contraseñas { get; set; }
        public string NombreUsuario { get; set; } 
        public string Clave { get; set; }
    }
}
