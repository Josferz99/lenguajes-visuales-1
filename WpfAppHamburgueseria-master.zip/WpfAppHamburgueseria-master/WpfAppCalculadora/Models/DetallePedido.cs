﻿namespace WpfAppHamburgueseria.Models
{
    public class DetallePedido
    {
        public int Id { get; set; }
        public int PedidoId { get; set; }
        public int HamburguesaId { get; set; }
        public int Cantidad { get; set; }
        public decimal Subtotal { get; set; }

        public Pedido Pedido { get; set; }
        public Hamburguesa Hamburguesa { get; set; }
    }
}
