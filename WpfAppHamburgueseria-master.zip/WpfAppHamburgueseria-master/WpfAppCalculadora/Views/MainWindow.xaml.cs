﻿using System.Windows;
using System.Windows.Controls;

namespace WpfAppHamburgueseria
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is ViewModels.LoginViewModel vm)
            {
                vm.Contraseña = ((PasswordBox)sender).Password;
            }
        }
    }
}
