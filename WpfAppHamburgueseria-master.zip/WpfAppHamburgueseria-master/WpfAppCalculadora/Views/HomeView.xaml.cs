﻿using System.Windows;

namespace WpfAppHamburgueseria.Views
{
    public partial class HomeView : Window
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}
