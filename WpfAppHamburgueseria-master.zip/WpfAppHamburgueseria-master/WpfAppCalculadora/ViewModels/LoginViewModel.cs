﻿using System.ComponentModel;
using System.Windows.Input;
using WpfAppHamburgueseria.Commands;
using WpfAppHamburgueseria.Services;

namespace WpfAppHamburgueseria.ViewModels
{
        public class LoginViewModel : BaseViewModel
    {
        private string _usuario;
        private string _contraseña;
        private string _mensaje;

        public string Usuario
        {
            get => _usuario;
            set { _usuario = value; OnPropertyChanged(nameof(Usuario)); }
        }

        public string Contraseña
        {
            get => _contraseña;
            set { _contraseña = value; OnPropertyChanged(nameof(Contraseña)); }
        }

        public string Mensaje
        {
            get => _mensaje;
            set { _mensaje = value; OnPropertyChanged(nameof(Mensaje)); }
        }

        public ICommand LoginCommand { get; }

        public LoginViewModel()
        {
            LoginCommand = new RelayCommand(ValidarLogin);
        }

        private void ValidarLogin(object parametro)
        {
            var servicio = new UsuarioService();
            bool valido = servicio.ValidarLogin(Usuario, Contraseña);

            Mensaje = valido ? "¡Bienvenido!" : "Usuario o contraseña incorrectos.";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string nombre)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nombre));
        }
    }
}
