﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using WpfAppHamburgueseria.Commands;
using WpfAppHamburgueseria.Data;
using WpfAppHamburgueseria.Models;

namespace WpfAppHamburgueseria.ViewModels
{
    public class PedidoViewModel : BaseViewModel
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private Hamburguesa _selectedHamburguesa;
        private string _nombre;
        private string _descripcion;
        private decimal _precio;
        private string _buscarNombre;
        private string _mensaje;

        public ObservableCollection<Hamburguesa> Hamburguesas { get; set; }

        // Comandos
        public ICommand AgregarCommand { get; }
        public ICommand EditarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand BuscarCommand { get; }
        public ICommand LimpiarCommand { get; }

        public PedidoViewModel()
        {
            Hamburguesas = new ObservableCollection<Hamburguesa>();
            AgregarCommand = new RelayCommand(Agregar);
            EditarCommand = new RelayCommand(Editar, PuedeEditarEliminar);
            EliminarCommand = new RelayCommand(Eliminar, PuedeEditarEliminar);
            BuscarCommand = new RelayCommand(Buscar);
            LimpiarCommand = new RelayCommand(Limpiar);

            CargarHamburguesas();
        }

        public Hamburguesa SelectedHamburguesa
        {
            get => _selectedHamburguesa;
            set
            {
                _selectedHamburguesa = value;
                if (value != null)
                {
                    Nombre = value.Nombre;
                    Descripcion = value.Descripcion;
                    Precio = value.Precio;
                }
                OnPropertyChanged(nameof(SelectedHamburguesa));
            }
        }

        public string Nombre
        {
            get => _nombre;
            set { _nombre = value; OnPropertyChanged(nameof(Nombre)); }
        }

        public string Descripcion
        {
            get => _descripcion;
            set { _descripcion = value; OnPropertyChanged(nameof(Descripcion)); }
        }

        public decimal Precio
        {
            get => _precio;
            set { _precio = value; OnPropertyChanged(nameof(Precio)); }
        }

        public string BuscarNombre
        {
            get => _buscarNombre;
            set { _buscarNombre = value; OnPropertyChanged(nameof(BuscarNombre)); }
        }

        public string Mensaje
        {
            get => _mensaje;
            set { _mensaje = value; OnPropertyChanged(nameof(Mensaje)); }
        }

        private void CargarHamburguesas()
        {
            using (var db = new AppDbContext())
            {
                Hamburguesas.Clear();
                foreach (var h in db.Hamburguesa.ToList())
                    Hamburguesas.Add(h);
            }
        }

        private void Agregar(object obj)
        {
            Mensaje = "";
            if (string.IsNullOrWhiteSpace(Nombre))
            {
                Mensaje = "El nombre es obligatorio.";
                return;
            }
            if (Precio <= 0)
            {
                Mensaje = "El precio debe ser mayor a cero.";
                return;
            }

            using (var db = new AppDbContext())
            {
                var nueva = new Hamburguesa { Nombre = Nombre, Descripcion = Descripcion, Precio = Precio };
                db.Hamburguesa.Add(nueva);
                db.SaveChanges();
            }
            CargarHamburguesas();
            Limpiar(null);
        }

        private void Editar(object obj)
        {
            if (SelectedHamburguesa == null) return;

            Mensaje = "";
            if (string.IsNullOrWhiteSpace(Nombre))
            {
                Mensaje = "El nombre es obligatorio.";
                return;
            }
            if (Precio <= 0)
            {
                Mensaje = "El precio debe ser mayor a cero.";
                return;
            }

            using (var db = new AppDbContext())
            {
                var h = db.Hamburguesa.Find(SelectedHamburguesa.Id);
                if (h != null)
                {
                    h.Nombre = Nombre;
                    h.Descripcion = Descripcion;
                    h.Precio = Precio;
                    db.SaveChanges();
                }
            }
            CargarHamburguesas();
            Limpiar(null);
        }

        private void Eliminar(object obj)
        {
            if (SelectedHamburguesa == null) return;
            using (var db = new AppDbContext())
            {
                var h = db.Hamburguesa.Find(SelectedHamburguesa.Id);
                if (h != null)
                {
                    db.Hamburguesa.Remove(h);
                    db.SaveChanges();
                }
            }
            CargarHamburguesas();
            Limpiar(null);
        }

        private void Buscar(object obj)
        {
            using (var db = new AppDbContext())
            {
                Hamburguesas.Clear();
                var lista = db.Hamburguesa
                    .Where(h => string.IsNullOrEmpty(BuscarNombre) || h.Nombre.Contains(BuscarNombre))
                    .ToList();
                foreach (var h in lista)
                    Hamburguesas.Add(h);
            }
        }

        private void Limpiar(object obj)
        {
            Nombre = "";
            Descripcion = "";
            Precio = 0;
            SelectedHamburguesa = null;
            Mensaje = "";
        }

        private bool PuedeEditarEliminar(object obj) => SelectedHamburguesa != null;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}