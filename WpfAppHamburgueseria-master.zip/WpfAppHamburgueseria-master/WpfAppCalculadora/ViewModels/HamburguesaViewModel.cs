﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using WpfAppHamburgueseria.Models;
using WpfAppHamburgueseria.Services;

namespace WpfAppHamburgueseria.ViewModels
{
    public class HamburguesaViewModel : BaseViewModel
    {
        public ObservableCollection<Pedido> Pedidos { get; set; }

        public HamburguesaViewModel(int usuarioId)
        {
            Pedidos = new ObservableCollection<Pedido>();
            var servicio = new PedidoService();

            foreach (var pedido in servicio.ObtenerPorUsuario(usuarioId))
                Pedidos.Add(pedido);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string nombre)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nombre));
        }
    }
}
