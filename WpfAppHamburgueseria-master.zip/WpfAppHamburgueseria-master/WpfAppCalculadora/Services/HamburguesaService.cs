﻿using System.Collections.Generic;
using System.Linq;
using WpfAppHamburgueseria.Data;
using WpfAppHamburgueseria.Models;

namespace WpfAppHamburgueseria.Services
{
    public class HamburguesaService
    {
        public List<Hamburguesa> ObtenerTodas()
        {
            using var context = new AppDbContext();
            return context.Hamburguesa.ToList();
        }

        public void Agregar(Hamburguesa nueva)
        {
            using var context = new AppDbContext();
            context.Hamburguesa.Add(nueva);
            context.SaveChanges();
        }

        public void Actualizar(Hamburguesa h)
        {
            using var context = new AppDbContext();
            context.Hamburguesa.Update(h);
            context.SaveChanges();
        }

        public void Eliminar(int id)
        {
            using var context = new AppDbContext();
            var h = context.Hamburguesa.Find(id);
            if (h != null)
            {
                context.Hamburguesa.Remove(h);
                context.SaveChanges();
            }
        }
    }
}
