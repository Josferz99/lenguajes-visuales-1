﻿using System.Collections.Generic;
using System.Linq;
using WpfAppHamburgueseria.Data;
using WpfAppHamburgueseria.Models;

namespace WpfAppHamburgueseria.Services
{
    public class PedidoService
    {
        public List<Pedido> ObtenerPorUsuario(int usuarioId)
        {
            using var context = new AppDbContext();
            return context.Pedido
                .Where(p => p.UsuarioId == usuarioId)
                .ToList();
        }

        public void RegistrarPedido(Pedido nuevo)
        {
            using var context = new AppDbContext();
            context.Pedido.Add(nuevo);
            context.SaveChanges();
        }
    }
}
