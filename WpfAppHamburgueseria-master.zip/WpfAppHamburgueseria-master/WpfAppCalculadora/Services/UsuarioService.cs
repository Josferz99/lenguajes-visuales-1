﻿using System.Linq;
using WpfAppHamburgueseria.Data;
using WpfAppHamburgueseria.Models;

namespace WpfAppHamburgueseria.Services
{
    public class UsuarioService
    {
        public bool ValidarLogin(string usuario, string contraseña)
        {
            using var context = new AppDbContext();
            return context.Usuario.Any(u =>
                u.NombreUsuario == usuario && u.Clave == contraseña);
        }

        public void Registrar(Usuario nuevo)
        {
            using var context = new AppDbContext();
            context.Usuario.Add(nuevo);
            context.SaveChanges();
        }
    }
}
