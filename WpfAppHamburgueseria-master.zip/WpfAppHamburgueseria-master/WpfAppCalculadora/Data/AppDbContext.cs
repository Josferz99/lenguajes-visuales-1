﻿using Microsoft.EntityFrameworkCore;
using WpfAppHamburgueseria.Models;


namespace WpfAppHamburgueseria.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<Hamburguesa> Hamburguesa { get; set; }
        public DbSet<Pedido> Pedido { get; set; }
        public DbSet<DetallePedido> DetallesPedido { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                "Server=NBBGG158\\SQLEXPRESS;Database=HamburgueseriaDB;User Id=admin;Password=Hamburguesa*2025;"
            );
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DetallePedido>()
                .HasOne(d => d.Pedido)
                .WithMany(p => p.Detalles)
                .HasForeignKey(d => d.PedidoId);

            modelBuilder.Entity<DetallePedido>()
                .HasOne(d => d.Hamburguesa)
                .WithMany()
                .HasForeignKey(d => d.HamburguesaId);
        }
    }
}
